from .settings import *

DEBUG = True
ALLOWED_HOSTS = ['*']