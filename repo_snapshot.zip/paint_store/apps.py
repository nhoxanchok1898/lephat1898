from django.apps import AppConfig

class PaintStoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'paint_store'