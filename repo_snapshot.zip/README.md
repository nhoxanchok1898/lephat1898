# Paint Store

Local Django development site for a small paint e‑commerce demo.

Quick start (development)

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_store
python manage.py assign_placeholders
python manage.py runserver 0.0.0.0:8888
```

Admin

```bash
python manage.py createsuperuser
```

Production (examples)

- Provide an `.env` file from `.env.example` with `DJANGO_SECRET_KEY`, `SITE_URL`, `ALLOWED_HOSTS`.
- Build and run with Docker Compose (example):

```bash
docker-compose build
docker-compose up -d
```

- Or deploy using Gunicorn + Nginx (see `RUNBOOK.md` for systemd/nginx snippets).

CI

- A GitHub Actions workflow is included at `.github/workflows/ci.yml` to run migrations and tests on push/PR to `main`.

Testing

```bash
python manage.py test
```

Notes
- The project includes simple QA scripts under `tools/` and a `RUNBOOK.md` with deployment guidance.
- Before production, ensure `DEBUG=False`, secure `DJANGO_SECRET_KEY`, and restrict `ALLOWED_HOSTS`.
